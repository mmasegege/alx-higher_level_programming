#!/usr/bin/node
const myVar = 'JavaScript is amazing';
console.log(myVar);
