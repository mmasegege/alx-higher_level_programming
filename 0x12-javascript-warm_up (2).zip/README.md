0x12. JavaScript - Warm up
